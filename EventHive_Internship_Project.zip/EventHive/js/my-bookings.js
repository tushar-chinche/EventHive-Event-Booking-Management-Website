
document.addEventListener("DOMContentLoaded", renderBookings);

function renderBookings() {
  const container = document.querySelector("#bookingsList");
  const bookings = JSON.parse(localStorage.getItem("eventHiveBookings") || "[]");
  document.querySelector("#bookingCount").textContent = `${bookings.length} booking${bookings.length !== 1 ? "s" : ""}`;

  if (!bookings.length) {
    container.innerHTML = `<div class="empty"><div style="font-size:48px">🎟️</div><h3>No bookings yet</h3><p>Your confirmed event bookings will appear here.</p><br><a class="btn btn-primary" href="events.html">Explore Events</a></div>`;
    return;
  }

  container.innerHTML = bookings.map((b, index) => `
    <article class="booking-card">
      <img src="${b.image}" alt="${b.eventName}">
      <div class="booking-content">
        <h3>${b.eventName}</h3>
        <div class="meta">📅 ${formatDate(b.eventDate)} &nbsp; • &nbsp; 📍 ${b.venue}</div>
        <div class="meta">🎟️ ${b.tickets} ticket${b.tickets !== 1 ? "s" : ""} &nbsp; • &nbsp; <strong>${formatCurrency(b.total)}</strong></div>
        <div class="meta">Booking ID: ${b.bookingId}</div>
        <div class="booking-actions">
          <a class="btn btn-outline" href="event-details.html?id=${b.eventId}">View Event</a>
          <button class="btn btn-danger" onclick="cancelBooking(${index})">Cancel Booking</button>
        </div>
      </div>
    </article>`).join("");
}

function cancelBooking(index) {
  const bookings = JSON.parse(localStorage.getItem("eventHiveBookings") || "[]");
  if (!confirm("Are you sure you want to cancel this booking?")) return;
  bookings.splice(index, 1);
  localStorage.setItem("eventHiveBookings", JSON.stringify(bookings));
  renderBookings();
  showToast("Booking cancelled successfully.");
}

function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2500);
}
window.cancelBooking = cancelBooking;

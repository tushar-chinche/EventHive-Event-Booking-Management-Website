
const API_URL = "data/events.json";

async function fetchEvents() {
  const response = await fetch(API_URL);
  if (!response.ok) throw new Error("Unable to load event data.");
  return await response.json();
}

function formatDate(dateString) {
  return new Intl.DateTimeFormat("en-IN", {
    day: "numeric", month: "short", year: "numeric"
  }).format(new Date(`${dateString}T00:00:00`));
}

function formatCurrency(amount) {
  return `₹${Number(amount).toLocaleString("en-IN")}`;
}

function getEventById(events, id) {
  return events.find(event => String(event.id) === String(id));
}

function eventCardTemplate(event) {
  return `
    <article class="event-card">
      <div class="event-img">
        <img src="${event.image}" alt="${event.name}" loading="lazy">
        <span class="badge">${event.category}</span>
      </div>
      <div class="event-body">
        <h3>${event.name}</h3>
        <div class="meta"><i>📅</i><span>${formatDate(event.date)}</span></div>
        <div class="meta"><i>📍</i><span>${event.venue}</span></div>
        <div class="price-row">
          <span class="price">${formatCurrency(event.price)} <small>/ ticket</small></span>
          <a class="btn btn-outline" href="event-details.html?id=${event.id}">View Details</a>
        </div>
      </div>
    </article>`;
}

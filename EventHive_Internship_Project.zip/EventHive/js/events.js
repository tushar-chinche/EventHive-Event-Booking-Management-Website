
let allEvents = [];

document.addEventListener("DOMContentLoaded", async () => {
  const grid = document.querySelector("#eventsGrid");
  if (!grid) return;

  const params = new URLSearchParams(location.search);
  document.querySelector("#eventSearch").value = params.get("search") || "";

  showLoading();
  try {
    allEvents = await fetchEvents();
    populateCategories();
    applyFilters();
  } catch (error) {
    grid.innerHTML = `<div class="error">Failed to load events, please try again.</div>`;
  }

  ["eventSearch","categoryFilter","dateFilter","priceFilter","sortFilter"]
    .forEach(id => document.querySelector(`#${id}`)?.addEventListener("input", applyFilters));
});

function showLoading() {
  document.querySelector("#eventsGrid").innerHTML = `<div class="loading">Loading events...</div>`;
}

function populateCategories() {
  const select = document.querySelector("#categoryFilter");
  [...new Set(allEvents.map(e => e.category))].sort().forEach(category => {
    select.insertAdjacentHTML("beforeend", `<option value="${category}">${category}</option>`);
  });
}

function applyFilters() {
  const search = document.querySelector("#eventSearch").value.toLowerCase().trim();
  const category = document.querySelector("#categoryFilter").value;
  const dateFilter = document.querySelector("#dateFilter").value;
  const price = document.querySelector("#priceFilter").value;
  const sort = document.querySelector("#sortFilter").value;

  let filtered = allEvents.filter(event => {
    const matchesSearch = !search || `${event.name} ${event.category} ${event.venue}`.toLowerCase().includes(search);
    const matchesCategory = !category || event.category === category;
    const eventDate = new Date(`${event.date}T00:00:00`);
    const today = new Date(); today.setHours(0,0,0,0);
    const days = Math.ceil((eventDate - today) / 86400000);
    const matchesDate =
      !dateFilter ||
      (dateFilter === "7" && days >= 0 && days <= 7) ||
      (dateFilter === "30" && days >= 0 && days <= 30) ||
      (dateFilter === "90" && days >= 0 && days <= 90);
    const matchesPrice =
      !price ||
      (price === "0-200" && event.price <= 200) ||
      (price === "201-500" && event.price >= 201 && event.price <= 500) ||
      (price === "501+" && event.price >= 501);
    return matchesSearch && matchesCategory && matchesDate && matchesPrice;
  });

  if (sort === "price-asc") filtered.sort((a,b) => a.price - b.price);
  if (sort === "date-asc") filtered.sort((a,b) => new Date(a.date) - new Date(b.date));

  renderEvents(filtered);
}

function renderEvents(events) {
  const grid = document.querySelector("#eventsGrid");
  document.querySelector("#resultCount").textContent = `${events.length} event${events.length !== 1 ? "s" : ""} found`;
  grid.innerHTML = events.length
    ? events.map(eventCardTemplate).join("")
    : `<div class="empty"><h3>No events found</h3><p>Try changing your search or filters.</p></div>`;
}

function clearFilters() {
  ["eventSearch","categoryFilter","dateFilter","priceFilter"].forEach(id => document.querySelector(`#${id}`).value = "");
  document.querySelector("#sortFilter").value = "";
  applyFilters();
}
window.clearFilters = clearFilters;


// Extra reusable validation helpers used by the booking module.
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function isValidPhone(phone) {
  return /^[6-9]\d{9}$/.test(phone);
}

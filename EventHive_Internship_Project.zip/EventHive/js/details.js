
document.addEventListener("DOMContentLoaded", async () => {
  const id = new URLSearchParams(location.search).get("id");
  const container = document.querySelector("#detailsContainer");
  if (!id) {
    container.innerHTML = `<div class="error">Event not found.</div>`;
    return;
  }

  try {
    const events = await fetchEvents();
    const event = getEventById(events, id);
    if (!event) throw new Error("Event not found");
    renderDetails(event);
  } catch (error) {
    container.innerHTML = `<div class="error">Unable to load this event. Please return to Events.</div>`;
  }
});

function renderDetails(event) {
  const container = document.querySelector("#detailsContainer");
  container.innerHTML = `
    <div class="details-grid">
      <div>
        <img id="mainImage" class="details-main-img" src="${event.image}" alt="${event.name}">
        <div class="gallery">${event.gallery.map(img => `<img src="${img}" alt="${event.name} gallery image">`).join("")}</div>
      </div>
      <div class="details">
        <span class="eyebrow">${event.category}</span>
        <h1>${event.name}</h1>
        <div class="detail-list">
          <div class="detail-item"><span>📅</span><div><strong>Date</strong><br>${formatDate(event.date)}</div></div>
          <div class="detail-item"><span>🕒</span><div><strong>Time</strong><br>${event.time}</div></div>
          <div class="detail-item"><span>📍</span><div><strong>Venue</strong><br>${event.venue}</div></div>
          <div class="detail-item"><span>👤</span><div><strong>Organizer</strong><br>${event.organizer}</div></div>
        </div>
        <p class="details-description">${event.description}</p>
        <div class="price-row">
          <span class="price">${formatCurrency(event.price)} <small>/ ticket</small></span>
          <a class="btn btn-primary" href="booking.html?id=${event.id}">Book Now →</a>
        </div>
      </div>
    </div>`;

  document.querySelectorAll(".gallery img").forEach(img => {
    img.addEventListener("click", () => document.querySelector("#mainImage").src = img.src);
  });
}

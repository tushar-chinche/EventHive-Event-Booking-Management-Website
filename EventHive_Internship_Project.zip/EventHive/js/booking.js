
let selectedEvent = null;

document.addEventListener("DOMContentLoaded", async () => {
  const id = new URLSearchParams(location.search).get("id");
  const form = document.querySelector("#bookingForm");
  if (!id || !form) return;

  try {
    const events = await fetchEvents();
    selectedEvent = getEventById(events, id);
    if (!selectedEvent) throw new Error("Event not found");
    document.querySelector("#bookingEvent").textContent = selectedEvent.name;
    document.querySelector("#bookingPrice").textContent = formatCurrency(selectedEvent.price);
    updateTotal();
  } catch (error) {
    document.querySelector("#bookingPage").innerHTML = `<div class="error">Event could not be loaded.</div>`;
    return;
  }

  document.querySelector("#tickets").addEventListener("input", updateTotal);
  form.addEventListener("submit", handleBooking);
});

function updateTotal() {
  const count = Math.max(1, Number(document.querySelector("#tickets").value || 1));
  document.querySelector("#totalPrice").textContent = formatCurrency(selectedEvent.price * count);
}

function handleBooking(e) {
  e.preventDefault();
  clearValidation();

  const name = document.querySelector("#name").value.trim();
  const email = document.querySelector("#email").value.trim();
  const phone = document.querySelector("#phone").value.trim();
  const tickets = Number(document.querySelector("#tickets").value);

  let valid = true;
  if (name.length < 2) { showError("nameError","Please enter your full name."); valid = false; }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showError("emailError","Please enter a valid email address."); valid = false; }
  if (!/^[6-9]\d{9}$/.test(phone)) { showError("phoneError","Enter a valid 10-digit Indian mobile number."); valid = false; }
  if (!Number.isInteger(tickets) || tickets < 1 || tickets > 10) { showError("ticketsError","Tickets must be between 1 and 10."); valid = false; }

  if (!valid) return;

  const booking = {
    bookingId: `EH${Date.now()}`,
    eventId: selectedEvent.id,
    eventName: selectedEvent.name,
    eventDate: selectedEvent.date,
    venue: selectedEvent.venue,
    image: selectedEvent.image,
    name, email, phone, tickets,
    total: selectedEvent.price * tickets,
    bookedAt: new Date().toISOString()
  };

  const bookings = JSON.parse(localStorage.getItem("eventHiveBookings") || "[]");
  bookings.push(booking);
  localStorage.setItem("eventHiveBookings", JSON.stringify(bookings));

  document.querySelector("#confirmationDetails").innerHTML = `
    <p><strong>Booking ID:</strong> ${booking.bookingId}</p>
    <p><strong>Event:</strong> ${booking.eventName}</p>
    <p><strong>Date:</strong> ${formatDate(booking.eventDate)}</p>
    <p><strong>Tickets:</strong> ${booking.tickets}</p>
    <p><strong>Total:</strong> ${formatCurrency(booking.total)}</p>`;
  document.querySelector("#confirmationModal").classList.add("show");
  document.querySelector("#bookingForm").reset();
  updateTotal();
}

function showError(id, message) { document.querySelector(`#${id}`).textContent = message; }
function clearValidation() { document.querySelectorAll(".form-error").forEach(el => el.textContent = ""); }
function closeModal() { document.querySelector("#confirmationModal").classList.remove("show"); }
window.closeModal = closeModal;

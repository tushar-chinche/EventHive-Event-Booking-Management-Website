
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) toggle.addEventListener("click", () => links.classList.toggle("open"));

  const year = document.querySelector("#year");
  if (year) year.textContent = new Date().getFullYear();

  const heroSearch = document.querySelector("#heroSearch");
  if (heroSearch) {
    heroSearch.addEventListener("keydown", e => {
      if (e.key === "Enter") {
        const q = encodeURIComponent(heroSearch.value.trim());
        window.location.href = `events.html?search=${q}`;
      }
    });
  }

  loadFeaturedEvents();
});

async function loadFeaturedEvents() {
  const container = document.querySelector("#featuredEvents");
  if (!container) return;
  try {
    const events = await fetchEvents();
    container.innerHTML = events.slice(0, 6).map(eventCardTemplate).join("");
  } catch (error) {
    container.innerHTML = `<div class="error">Failed to load events. Please try again.</div>`;
  }
}

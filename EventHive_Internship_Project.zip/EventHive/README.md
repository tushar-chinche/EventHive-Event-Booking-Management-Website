# EventHive – Event Booking & Management Website

EventHive is a responsive event discovery and booking website created for the Infobharat Interns Web Development Internship task.

## Project Overview
Users can browse upcoming events, search and filter the event catalogue, view complete event details, book tickets, see a confirmation modal, and manage/cancel bookings stored in browser LocalStorage.

## Technologies Used
- HTML5
- CSS3
- JavaScript ES6+
- Fetch API
- DOM Manipulation
- LocalStorage
- JSON (simulated API)
- Google Fonts

## Features Implemented
- Responsive navigation with mobile hamburger menu
- Home page with logo, hero/banner, search, CTA buttons and featured events
- Dynamic event loading from `data/events.json` using Fetch API
- Events listing with responsive cards
- Live search without page reload
- Category filtering
- Date filtering
- Price-range filtering
- Price low-to-high sorting
- Date nearest-first sorting
- Event details page
- Event image gallery
- Booking form
- JavaScript validation for name, email, phone and ticket count
- Booking confirmation modal
- LocalStorage booking persistence
- My Bookings page
- Booking cancellation
- Empty state and API error/loading states
- Mobile/tablet/desktop responsive design

## Project Structure
```text
EventHive/
├── index.html
├── events.html
├── event-details.html
├── booking.html
├── my-bookings.html
├── css/
│   └── style.css
├── js/
│   ├── api.js
│   ├── script.js
│   ├── events.js
│   ├── details.js
│   ├── booking.js
│   ├── validation.js
│   └── my-bookings.js
├── data/
│   └── events.json
├── images/
└── README.md
```

## How to Run
Because the website uses the Fetch API to load `data/events.json`, run it through a local web server.

### VS Code + Live Server
1. Open the `EventHive` folder in VS Code.
2. Install the **Live Server** extension if it is not already installed.
3. Right-click `index.html`.
4. Select **Open with Live Server**.
5. The site should open at an address similar to `http://127.0.0.1:5500/`.

Do not open `index.html` directly with `file://`, because browser security can block Fetch API requests for the JSON file.

## API Integration
`js/api.js` contains:
```javascript
const API_URL = "data/events.json";
```
The website uses:
```javascript
fetch(API_URL)
```
to dynamically load event data. The JSON file acts as a free local mock API, which is allowed by the internship instructions.

## Booking Storage
Bookings are stored temporarily in:
```text
localStorage key: eventHiveBookings
```
No backend or database is required.

## Screenshots
Add your final screenshots here before submitting the internship task:
1. Home page
2. Events listing + filters
3. Event details
4. Booking form + confirmation
5. My Bookings
6. Mobile responsive view

## Video Demonstration Checklist
Record a short screen video showing:
- Home page
- Search
- Events listing
- Category/date/price filters
- Sorting
- Event details
- Image gallery
- Booking validation
- Booking confirmation
- My Bookings
- Cancellation
- Mobile responsive layout

## LinkedIn Post Checklist
Include:
- Project name: EventHive
- Project overview
- Main features
- Screenshots
- GitHub repository link
- Technologies used
- Key learnings
- Tag Infobharat Interns

## Notes
The event images are loaded from remote image URLs. An internet connection is recommended for the image gallery and fonts.
